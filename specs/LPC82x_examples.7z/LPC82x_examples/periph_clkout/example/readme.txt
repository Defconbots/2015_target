CLKOUT example

Example description
This example shows how to use the SYSCTL driver to enable a specific
clock source on the CLKOUT pin. To use this example, you'll need to
connect an oscilloscope to the CLKOUT pin on your board. See the
comments in the code for mapped pins for supported boards.

Special connection requirements
There are no special connection requirements for this example.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
