UART interrupt example with ring buffers

Example description
The UART example shows how to use the UART in interrupt mode with transmit
and receive ring buffers.

To use the example, connect a serial cable to the board's RS232/UART port and
start a terminal program to monitor the port.  The terminal program on the host
PC should be setup for 115200-8-N-1.
Once the example is started, a small message is printed on terminal. Any data
received will be returned back to the caller.

Special connection requirements
Need to connect with base board for using RS232/UART port
NXP LPCXpresso_824 board:
Connect the board to a base board or connect TX, RX and GND
from J2 [Arduino Digital Header] to an FTDI Cable. To use the VCOM UART,
the DEBUG_UART must be disabled in the code.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
