State Configurable Timer (SCT) example

Example description
The SCT example demonstrates the match functionality using the
State Configurable Timer.

Special connection requirements
There are no special connection requirements for this example.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
