UART API in ROM (USART API ROM) polling example

Example description
The UART_ROM example demonstrates using the USART API ROM functions
in polling mode for terminated data input and output and single byte
input and output.

Special connection requirements
See @ref LPCOPEN_8XX_BOARD_LPCXPRESSO_812 for information on how to
setup the UART port hardware with this example..

NXP LPCXpresso_824 board:
Connect the board to a base board or connect TX, RX and GND
from J2 [Arduino Digital Header] to an FTDI Cable. To use the VCOM UART,
the DEBUG_UART must be disabled in the code.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
