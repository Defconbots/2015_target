LPC8xx SPI master and slave example using spim and spis drivers

FIXME

Build procedures:
Visit the http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides
to get started building LPCOpen projects.
