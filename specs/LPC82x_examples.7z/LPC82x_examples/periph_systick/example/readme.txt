Systick example using timer-driven interrupts to flash LEDs

Example description
The Systick example simply blinks an LED at a periodic rate using the systick
timer. The LED state is toggled in the systick interrupt handler.

After a small period of flashing the LED, the ISP will be reinvoked via
the ROM IAP functions. This allows testing the chip CRP capability and
getting back control of the chip.

Special connection requirements
There are no special connection requirements for this example.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
