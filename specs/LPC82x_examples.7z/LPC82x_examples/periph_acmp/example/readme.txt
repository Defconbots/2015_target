Analog Comparator example.

Example description
The ACMP example demonstrates using the analog comparator.

This example configures the positive voltage input as the voltage
found on PIN0.0, which is trimmed through the potentiometer.
The output of the comparator is brought out to PIN0.15 and
the "operating voltage" can be measured at PIN0.0.
Adjust the POT up and down to adjust the voltage into the analog
comparator. When the voltage crosses the negative voltage input,
a CMP IRQ is fired. Based on which side of the voltage is in
reference to the bandgap, the LED state will change.

Special connection requirements
Board [NXP_LPCXPRESSO_812]: There are no special connection
requirements for this example.

Board [NXP_LPCXPRESSO_824]: Analog input is expected on PIN-A2
on port J5 [Analog In], when the input voltage goes greater than
0.9V the Green LED will turn OFF and will turn ON if the voltage
goes below 0.9V. If using EA base board 
http://www.embeddedartists.com/products/lpcxpresso/xpr_base.php
connect J27 PIN-1 to J11 PIN-3 to use the Trim-POT.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
