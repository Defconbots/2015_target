I2C bus slave example using the ROM API

Example description
This example shows how to configure I2C as a slave device in interrupt
mode using the ROM-based APIs.

Special connection requirements
IMOPRTANT NOTE:
This example requires a connection via I2C to an another LPC800 board with
external pullups (about 4.7K). Both boards should be connected together on pins
PIO14 and PIO15.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
