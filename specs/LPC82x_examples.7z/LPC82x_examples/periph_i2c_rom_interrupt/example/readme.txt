I2C bus master example using the ROM API and interrupt mode

Example description
This example shows how to configure, write, and read, I2C as a bus master in interrupt
mode using the ROM-based APIs.

This demo supports both 7-bit and 10-bit addressing, but only 7-bit addressing is
used in the example. After I2C is setup, the I2C master transmit and receive
functions are called to transmit and receive the LED state of on or off.

This demo accesses the on-board I2C GPIO Expander which only exists on the LPC812 Max board,
or the Embedded Artists base board. To successfully run this example on the LPC824 Max board 
it must be connected to the EA base board.

If the example is run on the LPC812 Xpresso board or the LPC824 Max board alone, 
this program will always get a NAK error.

When running this demo on the LPC812 Max (or LPC824 Max) board , the LED will flash and 
I2C signals will be present on the SCL and SDA pins of the board's J1 connector.

Special connection requirements
There are no special connection requirements for this example.


Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
