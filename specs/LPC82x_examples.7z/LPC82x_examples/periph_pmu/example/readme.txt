Power API example

Example description
The Power example demonstrates using the various power down modes.  The example puts 
the MCU into each of the power states (SLEEP, DEEP_SLEEP, POWER_DOWN, and DEEP_POWER_DOWN).

This example configures the pin interrupt channel 0 as falling edge 
wake up interrupt. The interrupt channel 0 is connected to GPIO pin 
PIO0-4 in GPIO block. The example will then flash the LED according to the following table.

Sleep:  		2 flashes
Deep_Sleep: 	4 flashes
Power_Down:		8 flashes
Deep_power_down:16 flashes

To wake up from sleep mode, press the Wake button.  

Note:  When waking up from Deep_power_down the MPU will resume at the reset vector.  When resuming
the PMU_PCON_DPDFLAG flag will be set which allows startup to detect cold start vs wake from 
deep_power_down.

Special connection requirements
There are no special connection requirements for this example.
On NXP LPCXpresso_824 board use SW1 (Wake) button to activate the interrupt

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
