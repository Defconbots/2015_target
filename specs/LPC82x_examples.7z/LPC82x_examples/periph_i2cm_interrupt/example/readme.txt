I2CM bus master example using interrupt mode

Example description
This example shows how to configure I2C as a bus master in interrupt mode using
the I2CM driver.

This example uses 7-bit addressing to periodically read temperature data from a temperature
sensor on the Motor Control board. After I2C is setup, the I2CM master receive and transmit
functions are called through the i2cm_15xx driver routines. The temperature data is transmitted 
to the Debug UART port (115000, N,8,1).

Special connection requirements
The Embedded Artists Motor Control board is required with the LPCXpresso board to use this
example.