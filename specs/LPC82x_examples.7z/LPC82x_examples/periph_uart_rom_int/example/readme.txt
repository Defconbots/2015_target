UART API in ROM (USART API ROM) interrupt example
=================================================

Example description
-------------------
The UART_ROM example demonstrates using the USART API ROM functions
in interrupt mode for terminated data input and output.

An example ringbuffer capability is also provided using the
uart_get_line() and uart_put_line() functions in interrupt mode.

Special connection requirements
See @ref LPCOPEN_8XX_BOARD_LPCXPRESSO_812 for information on how to
setup the UART port hardware with this example..

NXP LPCXpresso_824 board:
-------------------------
Connect the board to a base board or connect TX, RX and GND
from J2 [Arduino Digital Header] to an FTDI Cable. To use the VCOM UART,
the DEBUG_UART must be disabled in the code.
NOTE: When connecting to the base base make sure P3 Pin4 [RST] pin of the
Xpresso board is *NOT* connected to the base board for the debugger to work.

Build procedures
----------------
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
