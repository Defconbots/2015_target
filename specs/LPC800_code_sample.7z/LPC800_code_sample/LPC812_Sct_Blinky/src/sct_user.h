#ifndef __SCT_USER_H__
#define __SCT_USER_H__
#include "LPC8xx.h"

#define delay (10000000)
#endif
