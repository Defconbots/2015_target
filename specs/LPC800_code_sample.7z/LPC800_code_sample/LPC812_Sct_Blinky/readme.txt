Purpose:
Simple SCT program using the Red State which configures the SCT as a 32 bit timer
SCT toggles CTOUT0 upon match

Running mode:
* Compile, Flash the program and reset.
* Default project target set to Blinky_Release (exectuing from flash)

Note:
Tested on LPC800 LPCXpresso Board
LPC800 running at 24 MHz

Output:
PIO0_7 configured as CTOUT_0, and Red LED connected to PIO0_7 toggles.


 