void SwitchMatrix_Init();
