#ifndef __SCT_USER_H__
#define __SCT_USER_H__
#include "LPC8xx.h"

#define C_pwm_cycle (1000000)
#define C_pwm_val1 (400000)
#define C_pwm_val2 (500000)
#define C_pwm_val3 (100000)
#define C_pwm_val4 (900000)
#endif
