#ifndef __SCT_USER_H__
#define __SCT_USER_H__
#include "the_real_sct_user.h"

#define val_match_max_width (max_pulse_width)
#define val_match_min_width (min_pulse_width)
#define val_match_no_input (timeout_value)
#endif
