#ifndef __SCT_USER_H__
#define __SCT_USER_H__
#include "LPC8xx.h"

#define C_match_green_OFF (5000000)
#define C_match_green_ON (4000000)
#define C_match_red_OFF (9000000)
#define C_match_red_ON (1000000)
#define delay (10000000)
#endif
