#include <cr_section_macros.h>

int main(void)
{
    return 0 ;
}
