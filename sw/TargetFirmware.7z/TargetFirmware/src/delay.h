#ifndef DELAY_H
#define DELAY_H

extern void Delay(uint32_t delay_time);
extern void DelayDumb(uint32_t delay_time);

#endif // DELAY_H
